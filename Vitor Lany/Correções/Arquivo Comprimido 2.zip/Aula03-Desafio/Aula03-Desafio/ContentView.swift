//
//  ContentView.swift
//  Aula03-Desafio
//
//  Created by edilsonalmeida on 20/01/23.
//

import SwiftUI

struct ContentView: View {
    
        @State private var segundaTela = false
        
        var aluno = Aluno(
            name: "Edilson",
            surname: "Almeida",
            website: "hackatruck.com.br",
            nickname: "edilsonalmeida__"
        )
    
    
    
    
    
    
    
    
    
    
    
        
        var body: some View {

            NavigationStack {
                    VStack {
                        NavigationLink(destination: SegundaTela(aluno: aluno)) {
                            Text("Modo 1")
                        }
                        
                        
                        
                        NavigationLink(destination: TerceiraTela(nome: aluno.name)) {
                            Text("Modo 2")
                        }
                        
                        Button(action: {
                            self.segundaTela.toggle()
                        }, label: {
                            Text("Modo3")
                        })
                        .sheet(isPresented: $segundaTela){
                            SegundaTela(aluno: aluno)
                        }
                    }
                }
        }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
