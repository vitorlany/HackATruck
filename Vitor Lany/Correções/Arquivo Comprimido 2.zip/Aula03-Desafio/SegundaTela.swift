//
//  SegundaTela.swift
//  Aula03-Desafio
//
//  Created by edilsonalmeida on 20/01/23.
//

import SwiftUI

struct SegundaTela: View {
    var aluno: Aluno
    var body: some View {
        VStack {
            Text(aluno.name)
            Text(aluno.surname)
            Text(aluno.website)
            Text(aluno.nickname)
        }
    }
}



struct SegundaTela_Previews: PreviewProvider {
    static let alunoTeste = Aluno(
          name: "Tiago",
          surname: "Pereira",
          website: "hackatruck.com.br",
          nickname: "@tiagogogo"
      )
    
    static var previews: some View {
        SegundaTela(aluno: alunoTeste)
    }
}


