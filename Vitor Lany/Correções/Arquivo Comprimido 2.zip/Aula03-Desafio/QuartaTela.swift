//
//  QuartaTela.swift
//  Aula03-Desafio
//
//  Created by edilsonalmeida on 20/01/23.
//

import SwiftUI

struct QuartaTela: View {
    var nome: String
    
    var body: some View {
        Text("Volte \(nome)!!")
    }
}

struct QuartaTela_Previews: PreviewProvider {
    static var previews: some View {
       var nome = ""
        QuartaTela(nome: nome)
    }
}
