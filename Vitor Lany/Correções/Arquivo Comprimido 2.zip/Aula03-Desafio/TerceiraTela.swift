//
//  TerceiraTela.swift
//  Aula03-Desafio
//
//  Created by edilsonalmeida on 20/01/23.
//

import SwiftUI

struct TerceiraTela: View {

    @State var nome : String
    
    var body: some View {
        
            VStack {
                
                TextField("Nome", text: $nome)
                
                Text("Estamos percorrendo um caminho \(nome)")
                
                NavigationLink(destination: QuartaTela(nome: nome)) {
                    Text("Acessar Tela")
                }

            }
    }
}

struct TerceiraTela_Previews: PreviewProvider {
    static var previews: some View {
        
        TerceiraTela(nome: "teste")
    }
}
