//
//  ContentView.swift
//  Aula03
//
//  Created by edilsonalmeida on 20/01/23.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        TabView {
                    
                    HomeView()
                        .badge(2)
                        .tabItem {
                            Label("Home", systemImage: "figure.stand.line.dotted.figure.stand")
                        }
                    
                    SearchView()
                        .tabItem {
                            Image(systemName: "magnifyingglass")
                        }

                    PhotoView()
                        .tabItem {
                            Text("Photos")
                            Image(systemName: "photo.fill")
                            
                        }

                    Text("Message view")
                        .badge("!")
                        .tabItem {
                            Text("Messages")
                        }

                    Profile()
                        .tabItem {
                            Image(systemName: "person.crop.circle.fill")
                            Text("Profile")
                        }
                    
        } //TabView
    }
}







struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
