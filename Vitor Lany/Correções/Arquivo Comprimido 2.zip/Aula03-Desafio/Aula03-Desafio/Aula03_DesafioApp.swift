//
//  Aula03_DesafioApp.swift
//  Aula03-Desafio
//
//  Created by edilsonalmeida on 20/01/23.
//

import SwiftUI

@main
struct Aula03_DesafioApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
