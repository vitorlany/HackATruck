//
//  SearchView.swift
//  Aula03
//
//  Created by edilsonalmeida on 03/03/23.
//

import SwiftUI

struct SearchView: View {
    var body: some View {
        Text("Hello, Hackatruck!")
            .frame(width: 300 ,height: 300)
            .background(.blue)
    }
}

struct SearchView_Previews: PreviewProvider {
    static var previews: some View {
        SearchView()
    }
}
