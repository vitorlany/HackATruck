//
//  Aula03App.swift
//  Aula03
//
//  Created by edilsonalmeida on 20/01/23.
//

import SwiftUI

@main
struct Aula03App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
