//
//  HomeView.swift
//  Aula03
//
//  Created by edilsonalmeida on 20/01/23.
//

import SwiftUI

struct HomeView: View {
    
    var body: some View {
        
        List(1...50, id: \.self) {
            Text("Item \($0)")
        }
        
    } //body
    
} //HomeView

struct HomeView_Previews: PreviewProvider {
    static var previews: some View {
        HomeView()
    }
}
