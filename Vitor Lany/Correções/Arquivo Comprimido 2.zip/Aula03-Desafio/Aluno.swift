import Foundation

struct Aluno {
    var name: String
    var surname: String
    var website: String
    var nickname: String
}
