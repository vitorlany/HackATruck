//
//  Profile.swift
//  Aula03
//
//  Created by edilsonalmeida on 11/04/23.
//

import SwiftUI

struct Profile: View {
    var body: some View {
        Text("Cade a internet?")
    }
}

struct Profile_Previews: PreviewProvider {
    static var previews: some View {
        Profile()
    }
}
